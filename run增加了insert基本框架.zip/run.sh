#! /bin/bash
mkvirtualenv cdm_run
pip install -r requirements.txt
python run.py