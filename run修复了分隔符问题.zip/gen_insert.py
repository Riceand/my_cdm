import logging

from helper import is_empty
from cdmlib import convert_pk, convert_column_type, strip_list, \
    replace_space_in_name, get_table_name, get_str_item, get_column_values, \
    TABLE_COLUMN, KEY, DATA_TYPE, join_list_comma_line, join_all_part, \
    FOLDER_CDM, filter_not_empty_columns, remove_remark, find_first_col, \
    get_table_column_values, find_cell_pos, get_columns_by_title

HUB_TABLE = 'Table'
HUB_FIELD = 'Field'
FOLDER_INSERT = FOLDER_CDM + '/INSERT/'
SQL_INSERT_START = 'INSERT {{cdm_table_dataset}}.{}\n('
SQL_INSERT_MID = ')\nSELECT'
SQL_INSERT_END = 'FROM {{cdm_raw_dataset}}.{};'

def as_column(column):
    return 'NULL AS ' + column

def get_hub_table_names(the_sheet):
    hub_table_cols = get_columns_by_title(the_sheet, HUB_TABLE)
    hub_table_str = find_first_col(hub_table_cols, HUB_TABLE)
    logging.debug(hub_table_str)
    separator = ',' if hub_table_str.find(',') >= 0 else '\n'
    return strip_list(hub_table_str.split(separator))

def gen_insert_columns(the_sheet):
    return get_table_column_values(the_sheet)

def get_field_columns(the_sheet):
    columns = get_column_values(the_sheet, HUB_FIELD)
    return list(filter_not_empty_columns(columns))

def gen_as_columns(insert_columns):
    return list(map(as_column, insert_columns))

def gen_insert_sql(the_sheet, hub_table):
    table_name = get_table_name(the_sheet)
    insert_columns = gen_insert_columns(the_sheet)
    # field_columns = get_field_columns(the_sheet)
    as_columns = gen_as_columns(insert_columns)
    str_insert_columns = join_list_comma_line(insert_columns)
    str_select_columns = join_list_comma_line(as_columns)

    start = SQL_INSERT_START.format(table_name)
    end = SQL_INSERT_END.format(table_name)
    return join_all_part(start, str_insert_columns, SQL_INSERT_MID, \
      str_select_columns, end)
