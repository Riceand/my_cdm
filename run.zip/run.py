import logging

from cdmlib import FOLDERS, mkdirs, create_file, gen_ddl_sql, \
    write_sql, read_file, set_logger

set_logger(logging.INFO)

if __name__ == "__main__":
    logging.info('Start generate SQLs:')
    file_name = 'PhysicalModel.xlsm'
    sheets_file = read_file('test_sheets.txt')
    sheet_lines = sheets_file.readlines()

    # sheet_names = ['PARTY_REFERENCE', 'Party_relationship']
    for sheet_line in sheet_lines:
        sheet_name = sheet_line.strip()
        logging.info('Generating the "' + sheet_name + '" sheet.')
        for folder in FOLDERS:
            mkdirs(folder)
            write_sql(file_name, sheet_name, folder)

    logging.info('Done! All SQL generated.')
